package app.model.entity.transaction;

public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL,
    TRANSFER
}
